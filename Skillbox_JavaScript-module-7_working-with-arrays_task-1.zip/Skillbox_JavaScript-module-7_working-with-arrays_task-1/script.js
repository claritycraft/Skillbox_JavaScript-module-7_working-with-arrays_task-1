const books = [
    "Мастер и Маргарита",
    "Гарри Поттер",
    "За пропастью во ржи",
    "Властелин колец",
    "Дюна",
    "Отцы и дети"
];

const bookList = document.getElementById('bookList');
const addBookButton = document.getElementById('addBook');
const searchBookButton = document.getElementById('searchBook');

// Функция для отображения списка книг
function displayBooks() {
    bookList.innerHTML = '';
    books.forEach((book, index) => {
        const li = document.createElement('li');
        li.textContent = `${index + 1}) ${book}`;
        bookList.appendChild(li);
    });
}

// Обработчик для добавления книги
addBookButton.addEventListener('click', () => {
    const newBook = prompt('Введите название книги:');
    if (!newBook) {
        alert('Название книги не введено!');
        return;
    }
    books.push(newBook);
    displayBooks();
});

// Обработчик для поиска книги
searchBookButton.addEventListener('click', () => {
    const searchQuery = prompt('Введите название книги для поиска:');
    if (!searchQuery) return;

    const bookIndex = books.findIndex(book => book.toLowerCase() === searchQuery.toLowerCase());
    if (bookIndex === -1) {
        alert('Книга не найдена!');
        return;
    }

    const items = bookList.getElementsByTagName('li');
    Array.from(items).forEach(item => item.style.backgroundColor = ''); // Сброс выделений
    items[bookIndex].style.backgroundColor = 'yellow';
});

// Инициализация отображения списка книг
displayBooks();
